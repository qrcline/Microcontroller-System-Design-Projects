/*******************************************************************************
* File Name: Backlight.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Backlight_ALIASES_H) /* Pins Backlight_ALIASES_H */
#define CY_PINS_Backlight_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Backlight_0			(Backlight__0__PC)
#define Backlight_0_PS		(Backlight__0__PS)
#define Backlight_0_PC		(Backlight__0__PC)
#define Backlight_0_DR		(Backlight__0__DR)
#define Backlight_0_SHIFT	(Backlight__0__SHIFT)
#define Backlight_0_INTR	((uint16)((uint16)0x0003u << (Backlight__0__SHIFT*2u)))

#define Backlight_INTR_ALL	 ((uint16)(Backlight_0_INTR))


#endif /* End Pins Backlight_ALIASES_H */


/* [] END OF FILE */
